Dash PCB design
Note-: 
        1. Space on the left bottom corner is left for the power source as it's not decided yet.
        2. The current size of PCB - (8.7 x 7.8) cm,  OG PCB: (7.9 x 12.5)            
How to use：

At editor, Click the document icon on the topbar, via "Document" > "Open" > "EasyEDA Source", and select json file, then open it at the editor.

